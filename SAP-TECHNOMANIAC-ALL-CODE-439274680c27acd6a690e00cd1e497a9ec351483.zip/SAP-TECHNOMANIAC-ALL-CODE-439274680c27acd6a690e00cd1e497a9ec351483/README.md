https://www.youtube.com/channel/UCZmiS-vi3WWSvzbo_1wePFA

RAP Video series https://www.youtube.com/watch?v=fkU-H6iUQXI&list=PLqz8SLrkjv2ipD5e4SoycfP8wJIqZzPi0&index=1
